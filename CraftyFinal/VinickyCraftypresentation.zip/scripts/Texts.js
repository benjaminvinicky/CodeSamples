var introTexts = {
    Intro1: "I've been out here for days. I think I'll make camp here...",
    Intro2: "I should start this bonfire, just need some wood.",
    Intro3: "Luckily there's piles of it lying around...",
    Intro4: "I can interact with things by pressing the space bar.",
    Intro5: "That should be enough. I should go start the fire.",
    Intro6: "That's better."
}
var builderTexts = {
    Builder1: "My lord, thank the gods I found you.",
    Builder2: "In your absence, the kingdom was destroyed by the Fallen",
    Builder3: "Some citizens fled into the woods.",
    Builder4: "I found you from the smoke. Perhaps the others will too.",
    Builder5: "We should fortify and get the others. The fallen will surely attack.",
    Builder6: "Take this axe. Cut down the trees. We need lumber and room to grow.",
    Builder7: "Talk to me when you have over 2000 wood. We need shelter.",
    King1: "(...)",
    King2: ""
}